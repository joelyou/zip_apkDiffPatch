//
//  iOSZipPatch.m
//  iOSZipPatch
//
//  Created by ex_ouyq2 on 2025/12/3.
//  Copyright © 2025 housisong. All rights reserved.
//

#import "iOSZipPatch.h"
#import "Patcher.h"

@implementation iOSZipPatch

+ (int)patchWithOld:(NSString *)oldFileName
           withDiff:(NSString *)diffFileName
              toNew:(NSString *)outNewFileName
              tempUnCompressFile:(NSString *)tempUncompressFileName
{
    return [iOSZipPatch patchWithOld:oldFileName withDiff:diffFileName toNew:outNewFileName tempUnCompressFile:tempUncompressFileName byMemory:256*1024 byThreadNum:1];
}

+ (int)patchWithOld:(NSString *)oldFileName
           withDiff:(NSString *)diffFileName
              toNew:(NSString *)outNewFileName
              tempUnCompressFile:(NSString *)tempUncompressFileName
           byMemory:(int64_t)cacheMemory
        byThreadNum:(int)threadNum
{
    #define HPATCH_OPTIONS_ERROR 1
    const char* old_cstr=(oldFileName==NULL)?0:[oldFileName UTF8String];
    if ((diffFileName==NULL)||(outNewFileName==NULL)) return HPATCH_OPTIONS_ERROR;
    return ZipPatch(old_cstr, [diffFileName UTF8String], [outNewFileName UTF8String], cacheMemory, [tempUncompressFileName UTF8String], threadNum);
}

@end
