//
//  iOSZipPatch.h
//  iOSZipPatch
//
//  Created by ex_ouyq2 on 2025/12/3.
//  Copyright © 2025 housisong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface iOSZipPatch : NSObject

+ (int)patchWithOld:(NSString *)oldFileName
           withDiff:(NSString *)diffFileName
              toNew:(NSString *)outNewFileName
 tempUnCompressFile:(NSString *)tempUncompressFileName;

+ (int)patchWithOld:(NSString *)oldFileName
           withDiff:(NSString *)diffFileName
              toNew:(NSString *)outNewFileName
              tempUnCompressFile:(NSString *)tempUncompressFileName
           byMemory:(int64_t)cacheMemory
        byThreadNum:(int)threadNum;

@end
